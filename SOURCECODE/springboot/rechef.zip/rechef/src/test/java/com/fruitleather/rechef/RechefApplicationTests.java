package com.fruitleather.rechef;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RechefApplicationTests {

	@Test
	void contextLoads() {
	}

}
